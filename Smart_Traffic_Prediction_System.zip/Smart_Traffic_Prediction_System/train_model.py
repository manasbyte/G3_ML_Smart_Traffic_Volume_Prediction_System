from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "traffic_dataset.csv"
MODEL = ROOT / "traffic_model.pkl"
METRICS = ROOT / "model_metrics.json"

FEATURES = ["Road", "Hour", "Day_Number", "Is_Weekend", "Weather", "Is_Holiday", "Temperature_C"]
TARGET = "Traffic_Volume"

def train():
    if not DATA.exists():
        from generate_dataset import generate_dataset
        generate_dataset()
    df = pd.read_csv(DATA)
    X, y = df[FEATURES], df[TARGET]
    categorical = ["Road", "Weather"]
    numeric = [c for c in FEATURES if c not in categorical]
    prep = ColumnTransformer([
        ("categorical", OneHotEncoder(handle_unknown="ignore"), categorical),
        ("numeric", "passthrough", numeric),
    ])
    model = Pipeline([
        ("preprocess", prep),
        ("regressor", RandomForestRegressor(n_estimators=140, max_depth=16, min_samples_leaf=2, random_state=42, n_jobs=-1)),
    ])
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    metrics = {
        "MAE": round(float(mean_absolute_error(y_test, preds)), 2),
        "RMSE": round(float(mean_squared_error(y_test, preds) ** 0.5), 2),
        "R2": round(float(r2_score(y_test, preds)), 4),
        "test_rows": int(len(y_test)),
        "dataset_rows": int(len(df)),
        "features": FEATURES,
        "note": "Metrics are from synthetic data and do not demonstrate real-world traffic accuracy."
    }
    joblib.dump(model, MODEL)
    METRICS.write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2))
    return model, metrics

if __name__ == "__main__":
    train()
